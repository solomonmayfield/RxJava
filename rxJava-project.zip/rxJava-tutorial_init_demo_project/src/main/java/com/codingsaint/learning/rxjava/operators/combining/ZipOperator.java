package com.codingsaint.learning.rxjava.operators.combining;

import com.codingsaint.learning.rxjava.observer.DemoObserver;
import com.codingsaint.learning.rxjava.utils.RxUtils;
import io.reactivex.Observable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ZipOperator {

    //ZipOperator
    private static final Logger LOGGER = LoggerFactory.getLogger(ZipOperator.class);


    //ZipOperator
    public static void main(String... args) {
        LOGGER.info("ZipOperator Operator");

        Observable shapes = Observable.fromIterable(RxUtils.shapes(5));
        Observable numbers = Observable.fromIterable(RxUtils.postiveNumbers(5));

        numbers.zipWith(shapes,(o,o2) ->{
            return o.toString()+": " +o2.toString();
        }).subscribe(new DemoObserver());


    }
}
