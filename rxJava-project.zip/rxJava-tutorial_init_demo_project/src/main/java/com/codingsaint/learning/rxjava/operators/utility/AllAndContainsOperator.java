package com.codingsaint.learning.rxjava.operators.utility;

import com.codingsaint.learning.rxjava.utils.RxUtils;
import io.reactivex.Observable;
import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AllAndContainsOperator {
    //AllAndContainsOperator
    private static final Logger LOGGER = LoggerFactory.getLogger(AllAndContainsOperator.class);


    //ContainsOperator
    public static void main(String... args) {
        LOGGER.info("AllAndContainsOperator");

        Observable<Integer> positiveNumbers = Observable.fromIterable(RxUtils.postiveNumbers(10));
               positiveNumbers.contains(10).subscribe(new SingleObserver<Boolean>() {
                   @Override
                   public void onSubscribe(Disposable disposable) {

                   }

                   @Override
                   public void onSuccess(Boolean result) {
                       LOGGER.info("Do all of the events are greater than 5{}", result);
                   }

                   @Override
                   public void onError(Throwable throwable) {

                   }
               });



    }

    /* //AllOperator
    public static void main(String... args) {
        LOGGER.info("AllAndContainsOperator");

        Observable<Integer> positiveNumbers = Observable.fromIterable(RxUtils.postiveNumbers(10));
               positiveNumbers.all(integer -> integer>5
               ).subscribe(new SingleObserver<Boolean>() {
                   @Override
                   public void onSubscribe(Disposable disposable) {

                   }

                   @Override
                   public void onSuccess(Boolean result) {
                       LOGGER.info("Do all of the events are greater than 5{}", result);
                   }

                   @Override
                   public void onError(Throwable throwable) {

                   }
               });



    }*/
}
