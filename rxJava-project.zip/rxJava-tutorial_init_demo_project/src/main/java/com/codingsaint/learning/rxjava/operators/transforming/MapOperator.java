package com.codingsaint.learning.rxjava.operators.transforming;

import com.codingsaint.learning.rxjava.observer.DemoObserver;
import com.codingsaint.learning.rxjava.utils.RxUtils;
import io.reactivex.Observable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class MapOperator {

    private static final Logger LOGGER = LoggerFactory.getLogger(BufferOperator.class);

//Scan
    public static void main(String... args) {
        LOGGER.info("FlatMap Operator");
        List<Integer> numbers = RxUtils.postiveNumbers(10);
        Observable.fromIterable(numbers)
                .scan((integer, integer2) -> {
                    return integer + integer2;
                } ).subscribe(new DemoObserver());


    }

    public static Observable<Integer> twice(Integer integer){

        return Observable.create(observableEmitter -> {

            if (!observableEmitter.isDisposed()){
                observableEmitter.onNext(integer*2);
            }else{
                observableEmitter.onComplete();
            }
        });
    }

    //Map Operator
/* public static void main(String... args) {
        LOGGER.info("Map Operator");
        Observable.fromIterable(RxUtils.postiveNumbers(10))
                .map(integer -> {return  integer*2;})
                .subscribe(new DemoObserver());


    }*/
//Flatmap
/*    public static void main(String... args) {
        LOGGER.info("FlatMap Operator");
        List<Integer> positiveIntegers = RxUtils.postiveNumbers(10);
        Observable.fromIterable(positiveIntegers)
                .flatMap(integer -> {return twice(integer);})
                .subscribe(new DemoObserver());


    }

    public static Observable<Integer> twice(Integer integer){

        return Observable.create(observableEmitter -> {

            if (!observableEmitter.isDisposed()){
                observableEmitter.onNext(integer*2);
            }else{
                observableEmitter.onComplete();
            }
        });
    }*/


/*//Scan
    public static void main(String... args) {
        LOGGER.info("FlatMap Operator");
        List<Integer> numbers = RxUtils.postiveNumbers(10);
        Observable.fromIterable(numbers)
                .scan((integer, integer2) -> {
                    return integer + integer2;
                } ).subscribe(new DemoObserver());


    }

    public static Observable<Integer> twice(Integer integer){

        return Observable.create(observableEmitter -> {

            if (!observableEmitter.isDisposed()){
                observableEmitter.onNext(integer*2);
            }else{
                observableEmitter.onComplete();
            }
        });
    }*/

}
