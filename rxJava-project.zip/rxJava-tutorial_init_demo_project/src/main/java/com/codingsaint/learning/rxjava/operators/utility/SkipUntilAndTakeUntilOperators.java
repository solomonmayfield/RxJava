package com.codingsaint.learning.rxjava.operators.utility;

import com.codingsaint.learning.rxjava.observer.DemoObserver;
import com.codingsaint.learning.rxjava.utils.RxUtils;
import io.reactivex.Observable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.TimeUnit;

public class SkipUntilAndTakeUntilOperators {

    //SkipUntilAndTakeUntilOperators
    private static final Logger LOGGER = LoggerFactory.getLogger(SkipUntilAndTakeUntilOperators.class);


    //TakeUntilOperators
    public static void main(String... args) {
        LOGGER.info("TakeUntilOperators");

        Observable singleSecond = Observable.interval(1, TimeUnit.SECONDS);
        Observable fiveSecond = Observable.interval(5, TimeUnit.SECONDS);

        singleSecond.takeUntil(fiveSecond).subscribe(new DemoObserver());
        RxUtils.sleep(15000);


    }

    /*
    //SkipUntilOperators
    public static void main(String... args) {
        LOGGER.info("SkipUntilOperators");

        Observable singleSecond = Observable.interval(1, TimeUnit.SECONDS);
        Observable fiveSecond = Observable.interval(5, TimeUnit.SECONDS);

        singleSecond.skipUntil(fiveSecond).subscribe(new DemoObserver());
        RxUtils.sleep(15000);


    }*/
}
