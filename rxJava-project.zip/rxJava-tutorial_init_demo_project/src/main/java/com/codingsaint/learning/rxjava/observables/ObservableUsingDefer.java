package com.codingsaint.learning.rxjava.observables;

import com.codingsaint.learning.rxjava.observer.DemoObserver;
import com.codingsaint.learning.rxjava.utils.RxUtils;
import io.reactivex.Observable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ObservableUsingDefer {
    private static final Logger LOGGER = LoggerFactory.getLogger(ObservablesUsingJust.class);

    public static void main(String... args) {

        Observable<Integer> observableUsingDefer = Observable.defer(() ->{
           return Observable.fromIterable(RxUtils.postiveNumbers(5));
        });
        observableUsingDefer.subscribe(new DemoObserver());
        observableUsingDefer.subscribe(new DemoObserver());//both time observable has been created

    }

}



/*observableUsingDefer.subscribe(new Observer<Integer>() {
            @Override
            public void onSubscribe(Disposable disposable) {

            }

            @Override
            public void onNext(Integer integer) {LOGGER.info("onNext");}

            @Override
            public void onError(Throwable throwable) {

            }

            @Override
            public void onComplete() {

            }
        });*/